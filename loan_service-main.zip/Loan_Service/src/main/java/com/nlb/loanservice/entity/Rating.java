package com.nlb.loanservice.entity;

public enum Rating {
	POOR, OK , GOOD, VERYGOOD, EXCELLENT	
}
