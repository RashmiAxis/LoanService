package com.nlb.loanservice.service;

import java.util.NoSuchElementException;

import javax.validation.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nlb.loanservice.entity.LoanApplication;
import com.nlb.loanservice.entity.Rating;
import com.nlb.loanservice.entity.Status;
import com.nlb.loanservice.exception.LoanAlreadyExists;
import com.nlb.loanservice.exception.LoanBlankField;
import com.nlb.loanservice.exception.LoanGrantLimit;
import com.nlb.loanservice.repository.LoanApplicationRepository;

@Service
public class LoanApplicationServiceImpl implements ILoanApplicationService {
	
	@Autowired
	LoanApplicationRepository loanAppRepo;

	@Override
	public LoanApplication saveLoanApplication(LoanApplication loan){
		if(loanAppRepo.existsById(loan.getId())) {
			throw new LoanAlreadyExists("Already Exists");
		}else if(loan.getRequestedAmount() < 10000.0 || loan.getRequestedAmount() > 2000000.0) {
			throw new LoanGrantLimit("LoanAmount must between 1000 to 2000000.");
		}else if(loan.getBank() == ""){
			throw new LoanBlankField("Bank Name should not be empty");
		}else {
		
			LoanApplication loanApp1 = new LoanApplication();
			loanApp1.setId(loan.getId());
			loanApp1.setBank(loan.getBank());
			loanApp1.setRequestedAmount(loan.getRequestedAmount());
			loanApp1.setTermLength(loan.getTermLength());
			loanApp1.setMinintrestRate(10000);
			loanApp1.setMaxloanAmount(200000);
			loanApp1.setMinCreditScore(10);
			loanApp1.setMinintrestRate(7);
			loanApp1.setProcessingFee(loan.getRequestedAmount()*0.005);
			loanApp1.setStatus(Status.PENDING);
			loanApp1.setRating(Rating.OK);
			return loanAppRepo.save(loanApp1);
		}
	}

	@Override
	public LoanApplication approveLoanApplication(int loanId) throws NoSuchElementException {
		LoanApplication loanApp = loanAppRepo.findById(loanId).get();
		loanApp.setStatus(Status.APPROVED);
		loanAppRepo.save(loanApp);
		return loanApp;
	}

	@Override
	public LoanApplication rejectLoanApplication(int loanId) throws NoSuchElementException {
		LoanApplication loanApp = loanAppRepo.findById(loanId).get();
		loanApp.setStatus(Status.REJECTED);
		loanAppRepo.save(loanApp);
		return loanApp;
	}

}
