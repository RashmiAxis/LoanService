package com.nlb.loanservice.entity;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="LOAN")
public class LoanApplication {
	
	@Id
	private int Id;
	private String Bank;
	private Double requestedAmount = 0.0 ;
	
	private int minloanAmount;
	private int maxloanAmount;
	private int minintrestRate;
	private int minCreditScore;
	private int termLength;
	private Double processingFee = requestedAmount * 0.005;
	private Rating rating=Rating.OK;
	private Status status = Status.PENDING;

	
	
	public LoanApplication() {	super();	}
	
	
	public LoanApplication(int id, String bank,double requestedAmount, int minloanAmount, int maxloanAmount, int minintrestRate,
			int minCreditScore, int termLength, double processingFee, Rating rating, Status status) {
		Id = id;
		Bank = bank;
		this.requestedAmount = requestedAmount;
		this.minloanAmount = minloanAmount;
		this.maxloanAmount = maxloanAmount;
		this.minintrestRate = minintrestRate;
		this.minCreditScore = minCreditScore;
		this.termLength = termLength;
		this.processingFee = processingFee;
		this.rating = rating;
		this.status = status;
	}
	
	public int getId() {
		return Id;
	}


	public void setId(int id) {
		this.Id = id;
	}

	public String getBank() {
		return Bank;
	}
	public void setBank(String bank) {
		Bank = bank;
	}
	
	public double getRequestedAmount() {
		return requestedAmount;
	}


	public void setRequestedAmount(double requestedAmount) {
		this.requestedAmount = requestedAmount;
	}

	public int getMinloanAmount() {
		return minloanAmount;
	}
	public void setMinloanAmount(int minloanAmount) {
		this.minloanAmount = minloanAmount;
	}


	public int getMaxloanAmount() {
		return maxloanAmount;
	}
	
	public void setMaxloanAmount(int maxloanAmount) {
		this.maxloanAmount = maxloanAmount;
		}


	public int getMinintrestRate() {
		return minintrestRate;
	}
	public void setMinintrestRate(int minintrestRate) {
		this.minintrestRate = minintrestRate;
	}

	public int getMinCreditScore() {
		return minCreditScore;
	}
	public void setMinCreditScore(int minCreditScore) {
		this.minCreditScore = minCreditScore;
	}

	public int getTermLength() {
		return termLength;
	}
	public void setTermLength(int termLength) {
		this.termLength = termLength;
	}
	
	public double getProcessingFee() {
		return processingFee;
	}


	public void setProcessingFee(double processingFee) {
		this.processingFee = processingFee;
	}


	public Rating getRating() {
		return rating;
	}
	public void setRating(Rating rating) {
		this.rating = rating;
	}
	public Status getStatus() {
		return status;
	}


	public void setStatus(Status status) {
		this.status = status;
	}	
	
	
}
