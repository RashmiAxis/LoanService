package com.nlb.loanservice.entity;

public enum Status {
	PENDING, APPROVED, REJECTED, PROCESSING, INITIATED, COMPLETED
}
